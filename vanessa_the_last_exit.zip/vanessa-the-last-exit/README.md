# Vanessa: The Last Exit

A browser-based first-person survival horror game.

## Run locally
Open `index.html` in a modern browser.

## Publish with GitHub Pages
1. Create a new public GitHub repository, for example `vanessa-the-last-exit`.
2. Upload `index.html` to the repository root and commit it to the `main` branch.
3. Open the repository's Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select `main` and `/(root)`, then Save.
6. Wait for the Pages deployment. Your public URL will be:
   `https://YOUR-GITHUB-USERNAME.github.io/vanessa-the-last-exit/`

The game is static and needs no API key, backend, or build command.
